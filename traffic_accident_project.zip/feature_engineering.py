﻿"""
Feature engineering for risk analysis
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

def calculate_risk_profile(df, vehicle_columns):
    """
    Calculate Risk Profile Score
    
    Risk Profile = (% from vulnerable vehicles) / (% from heavy vehicles)
    Vulnerable: Motor Cycle/Moped, Three wheeler, Cycle
    Heavy: Lorry, SLT Bus, Private Bus, Intercity Bus, Articulated Vehicle
    """
    
    vulnerable = ['Motor Cycle/Moped', 'Three wheeler', 'Cycle']
    heavy = ['Lorry', 'SLT Bus', 'Private Bus', 'Intercity Bus', 'Articulated Vehicle, prime mover']
    
    # Get available columns
    vulnerable_cols = [v for v in vulnerable if v in df.columns]
    heavy_cols = [h for h in heavy if h in df.columns]
    
    # Calculate vulnerable percentage
    vulnerable_sum = df[vulnerable_cols].sum(axis=1)
    heavy_sum = df[heavy_cols].sum(axis=1)
    total = df[vehicle_columns].sum(axis=1)
    
    vulnerable_pct = (vulnerable_sum / total * 100).round(2)
    heavy_pct = (heavy_sum / total * 100).round(2)
    
    # Risk Profile Score (avoid division by zero)
    risk_profile = np.where(
        heavy_pct > 0,
        (vulnerable_pct / heavy_pct).round(2),
        100  # Very high risk if no heavy vehicles
    )
    
    df['Vulnerable_Pct'] = vulnerable_pct
    df['Heavy_Pct'] = heavy_pct
    df['Risk_Profile_Score'] = risk_profile
    
    return df

def categorize_risk(score):
    """Categorize risk into Low/Medium/High"""
    if score < 1.0:
        return 'Low (Heavy Vehicle Dominated)'
    elif score < 3.0:
        return 'Medium (Balanced)'
    else:
        return 'High (Vulnerable User Dominated)'

def add_risk_category(df):
    """Add risk category column"""
    df['Risk_Category'] = df['Risk_Profile_Score'].apply(categorize_risk)
    return df

def create_urban_rural_label(df):
    """Create urban/rural classification based on total accidents"""
    # Using percentiles to define urban/rural
    threshold_75 = df['Total_Accidents'].quantile(0.75)
    threshold_25 = df['Total_Accidents'].quantile(0.25)
    
    df['Area_Type'] = 'Rural'
    df.loc[df['Total_Accidents'] > threshold_75, 'Area_Type'] = 'Urban'
    df.loc[(df['Total_Accidents'] >= threshold_25) & (df['Total_Accidents'] <= threshold_75), 'Area_Type'] = 'Suburban'
    
    return df

def create_vehicle_density_features(df, vehicle_columns):
    """Create vehicle density features (count per 1000 accidents)"""
    total = df['Total_Accidents']
    
    for col in vehicle_columns:
        df[f'{col}_per_1k'] = (df[col] / total * 1000).round(2)
    
    return df

def engineer_all_features(df, vehicle_columns):
    """Run all feature engineering steps"""
    df = calculate_risk_profile(df, vehicle_columns)
    df = add_risk_category(df)
    df = create_urban_rural_label(df)
    df = create_vehicle_density_features(df, vehicle_columns)
    
    return df

if __name__ == "__main__":
    from data_loader import load_data, preprocess_data, get_vehicle_columns
    
    df = load_data()
    df, _, vehicle_cols = preprocess_data(df)
    df = engineer_all_features(df, vehicle_cols)
    
    print("\nRisk Profile Distribution:")
    print(df['Risk_Category'].value_counts())
    print("\nArea Type Distribution:")
    print(df['Area_Type'].value_counts())
