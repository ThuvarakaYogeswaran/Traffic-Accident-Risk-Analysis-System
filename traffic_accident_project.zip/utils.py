﻿"""
Utility functions for the dashboard
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor

def get_top_risk_locations(df, n=5):
    """Get top N highest risk locations"""
    return df.nlargest(n, 'Risk_Profile_Score')[['Location', 'Risk_Profile_Score', 'Risk_Category', 'Total_Accidents']]

def get_top_safe_locations(df, n=5):
    """Get top N lowest risk locations"""
    return df.nsmallest(n, 'Risk_Profile_Score')[['Location', 'Risk_Profile_Score', 'Risk_Category', 'Total_Accidents']]

def get_vehicle_impact_analysis(df, vehicle_columns):
    """Analyze vehicle type impact on risk"""
    X = np.log1p(df[vehicle_columns])
    y = df['Risk_Profile_Score']
    
    model = RandomForestRegressor(n_estimators=50, random_state=42)
    model.fit(X, y)
    
    importance_df = pd.DataFrame({
        'Vehicle_Type': vehicle_columns,
        'Impact_on_Risk': model.feature_importances_
    }).sort_values('Impact_on_Risk', ascending=False)
    
    return importance_df

def simulate_policy_change(df, location, vehicle_type, change_percent, vehicle_columns):
    """Simulate policy change impact"""
    location_data = df[df['Location'] == location].iloc[0].copy()
    new_value = location_data[vehicle_type] * (1 + change_percent / 100)
    location_data[vehicle_type] = max(0, new_value)
    
    vulnerable = ['Motor Cycle/Moped', 'Three wheeler', 'Cycle']
    heavy = ['Lorry', 'SLT Bus', 'Private Bus', 'Intercity Bus', 'Articulated Vehicle, prime mover']
    
    vulnerable_sum = sum(location_data.get(v, 0) for v in vulnerable if v in vehicle_columns)
    heavy_sum = sum(location_data.get(h, 0) for h in heavy if h in vehicle_columns)
    total = location_data[vehicle_columns].sum()
    
    vulnerable_pct = (vulnerable_sum / total * 100) if total > 0 else 0
    heavy_pct = (heavy_sum / total * 100) if total > 0 else 0
    new_risk_score = (vulnerable_pct / heavy_pct) if heavy_pct > 0 else 100
    
    return {
        'original_risk': location_data['Risk_Profile_Score'],
        'new_risk': new_risk_score,
        'change': new_risk_score - location_data['Risk_Profile_Score'],
        'change_percent': ((new_risk_score - location_data['Risk_Profile_Score']) / location_data['Risk_Profile_Score'] * 100) if location_data['Risk_Profile_Score'] > 0 else 0
    }

def get_statistics_summary(df):
    """Generate summary statistics"""
    stats = {
        'total_locations': len(df),
        'total_accidents': df['Total_Accidents'].sum(),
        'avg_accidents_per_location': df['Total_Accidents'].mean(),
        'high_risk_locations': len(df[df['Risk_Category'].str.contains('High')]),
        'medium_risk_locations': len(df[df['Risk_Category'].str.contains('Medium')]),
        'low_risk_locations': len(df[df['Risk_Category'].str.contains('Low')]),
        'highest_risk_location': df.loc[df['Risk_Profile_Score'].idxmax(), 'Location'],
        'highest_risk_score': df['Risk_Profile_Score'].max(),
        'most_accidents_location': df.loc[df['Total_Accidents'].idxmax(), 'Location'],
        'most_accidents_count': df['Total_Accidents'].max()
    }
    return stats

def format_number(num):
    """Format numbers with commas"""
    return f"{num:,}"
