﻿"""
Machine learning models for risk analysis and domain adaptation
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
from scipy.spatial.distance import jensenshannon
import warnings
warnings.filterwarnings('ignore')

class RiskProfileModel:
    """Main model for risk profile prediction"""
    
    def __init__(self):
        self.classifier = None
        self.regressor = None
        self.scaler = StandardScaler()
        self.is_fitted = False
        self.risk_categories = None
        
    def prepare_features(self, df, vehicle_columns):
        """Prepare features for modeling"""
        # Use vehicle counts as features
        X = df[vehicle_columns].copy()
        
        # Log transform to handle skewness
        X_log = np.log1p(X)
        
        return X_log
    
    def train_classifier(self, df, vehicle_columns):
        """Train risk category classifier"""
        X = self.prepare_features(df, vehicle_columns)
        y = df['Risk_Category']
        
        # Encode target
        self.risk_categories = y.unique()
        y_encoded = pd.Categorical(y).codes
        
        # Train
        self.classifier = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            class_weight='balanced'
        )
        
        X_scaled = self.scaler.fit_transform(X)
        self.classifier.fit(X_scaled, y_encoded)
        
        # Cross-validation
        cv_scores = cross_val_score(self.classifier, X_scaled, y_encoded, cv=5)
        
        self.is_fitted = True
        
        return {
            'cv_mean': cv_scores.mean(),
            'cv_std': cv_scores.std()
        }
    
    def train_regressor(self, df, vehicle_columns):
        """Train risk score regressor"""
        X = self.prepare_features(df, vehicle_columns)
        y = df['Risk_Profile_Score']
        
        self.regressor = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        
        X_scaled = self.scaler.fit_transform(X)
        self.regressor.fit(X_scaled, y)
        
        # Cross-validation
        cv_scores = cross_val_score(self.regressor, X_scaled, y, cv=5, scoring='r2')
        
        return {
            'r2_mean': cv_scores.mean(),
            'r2_std': cv_scores.std()
        }
    
    def predict_risk_category(self, X_new):
        """Predict risk category for new data"""
        if self.classifier is None:
            raise ValueError("Classifier not trained yet")
        
        X_scaled = self.scaler.transform(X_new)
        pred_encoded = self.classifier.predict(X_scaled)
        
        return self.risk_categories[pred_encoded]
    
    def predict_risk_score(self, X_new):
        """Predict risk score for new data"""
        if self.regressor is None:
            raise ValueError("Regressor not trained yet")
        
        X_scaled = self.scaler.transform(X_new)
        return self.regressor.predict(X_scaled)

class DomainAdaptation:
    """Domain adaptation for urban to rural transfer"""
    
    def __init__(self):
        self.source_scaler = None
        self.target_scaler = None
        
    def calculate_distribution_shift(self, source_df, target_df, vehicle_columns):
        """Calculate distribution shift between source and target domains"""
        shift_scores = {}
        
        for col in vehicle_columns:
            # Normalize to probability distribution
            source_dist = source_df[col] / source_df[col].sum()
            target_dist = target_df[col] / target_df[col].sum()
            
            # Jensen-Shannon divergence
            js_div = jensenshannon(source_dist, target_dist)
            shift_scores[col] = js_div
        
        return shift_scores
    
    def cora_alignment(self, source_features, target_features):
        """
        CORrelation ALignment (CORAL) for domain adaptation
        Aligns target feature distribution to source
        """
        # Compute source covariance
        source_cov = np.cov(source_features.T) + np.eye(source_features.shape[1]) * 1e-6
        target_cov = np.cov(target_features.T) + np.eye(target_features.shape[1]) * 1e-6
        
        # Compute alignment transformation
        source_cov_sqrt = np.linalg.cholesky(source_cov)
        source_cov_sqrt_inv = np.linalg.inv(source_cov_sqrt)
        
        transformation = source_cov_sqrt_inv @ np.linalg.cholesky(target_cov)
        
        # Apply transformation
        aligned_features = target_features @ transformation.T
        
        return aligned_features
    
    def prepare_urban_rural_split(self, df, vehicle_columns):
        """Split data into urban (source) and rural (target)"""
        urban_df = df[df['Area_Type'] == 'Urban'].copy()
        rural_df = df[df['Area_Type'] == 'Rural'].copy()
        
        X_urban = np.log1p(urban_df[vehicle_columns])
        X_rural = np.log1p(rural_df[vehicle_columns])
        
        return X_urban, X_rural, urban_df, rural_df

class TemporalSimulator:
    """Simulate temporal data for demonstration"""
    
    @staticmethod
    def generate_synthetic_time_series(df, vehicle_columns, n_years=3, noise_std=0.05):
        """Generate synthetic time series by adding noise to historical data"""
        time_series = []
        
        for year in range(n_years):
            df_year = df.copy()
            # Add compound growth/decline with noise
            for col in vehicle_columns:
                change = np.random.normal(0, noise_std * (year + 1))
                df_year[col] = df_year[col] * (1 + change)
                df_year[col] = df_year[col].clip(lower=0)
            
            df_year['Year'] = year + 2023
            time_series.append(df_year)
        
        return pd.concat(time_series, ignore_index=True)

if __name__ == "__main__":
    from data_loader import load_data, preprocess_data, get_vehicle_columns
    from feature_engineering import engineer_all_features
    
    # Test models
    df = load_data()
    df, _, vehicle_cols = preprocess_data(df)
    df = engineer_all_features(df, vehicle_cols)
    
    # Train model
    model = RiskProfileModel()
    classifier_results = model.train_classifier(df, vehicle_cols)
    regressor_results = model.train_regressor(df, vehicle_cols)
    
    print(f"Classifier CV Accuracy: {classifier_results['cv_mean']:.3f}")
    print(f"Regressor CV R2: {regressor_results['r2_mean']:.3f}")
    
    # Test domain adaptation
    da = DomainAdaptation()
    X_urban, X_rural, _, _ = da.prepare_urban_rural_split(df, vehicle_cols)
    shift_scores = da.calculate_distribution_shift(
        pd.DataFrame(X_urban), pd.DataFrame(X_rural), 
        vehicle_cols
    )
    print(f"\nAverage distribution shift: {np.mean(list(shift_scores.values())):.3f}")
