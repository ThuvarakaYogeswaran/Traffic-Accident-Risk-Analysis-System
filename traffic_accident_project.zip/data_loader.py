"""
Data loading and preprocessing module
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

def load_data(file_path="road_accident_data_by_vehicle_type.csv"):
    """Load the accident dataset"""
    df = pd.read_csv(file_path)
    return df

def clean_location_names(df):
    """Clean and standardize location names"""
    df['Location'] = df['Location'].str.strip()
    return df

def get_vehicle_columns(df):
    """Get list of vehicle type columns"""
    # Exclude only Location initially (Total_Accidents will be created later)
    exclude = ['Location']
    return [col for col in df.columns if col not in exclude]

def create_total_accidents(df, vehicle_columns):
    """Create total accidents column"""
    df['Total_Accidents'] = df[vehicle_columns].sum(axis=1)
    return df

def create_percentages(df, vehicle_columns):
    """Convert counts to percentages per location"""
    df_percent = df.copy()
    total = df[vehicle_columns].sum(axis=1)
    
    for col in vehicle_columns:
        df_percent[f'{col}_pct'] = (df[col] / total * 100).round(2)
    
    return df_percent

def preprocess_data(df):
    """Main preprocessing pipeline"""
    df = clean_location_names(df)
    vehicle_cols = get_vehicle_columns(df)  # This gets all columns except Location
    df = create_total_accidents(df, vehicle_cols)  # Now add Total_Accidents
    df_percent = create_percentages(df, vehicle_cols)
    
    return df, df_percent, vehicle_cols

if __name__ == "__main__":
    # Test the module
    df = load_data()
    df, df_percent, vehicle_cols = preprocess_data(df)
    print(f"Loaded {len(df)} locations")
    print(f"Found {len(vehicle_cols)} vehicle types")
    print(df.head())