﻿"""
Visualization functions for the dashboard
"""

import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from plotly.subplots import make_subplots

def create_risk_map(df):
    """Create interactive risk map"""
    # Create synthetic coordinates
    locations_coords = {
        'Colombo': (6.9271, 79.8612), 'Gampaha': (7.0891, 79.9935),
        'Kandy': (7.2906, 80.6337), 'Galle': (6.0328, 80.2153),
        'Kurunegala': (7.4868, 80.3644), 'Anuradhapura': (8.3114, 80.4037),
        'Badulla': (6.9934, 81.0553), 'Ratnapura': (6.6829, 80.3992),
        'Jaffna': (9.6615, 80.0255), 'Batticaloa': (7.7171, 81.7006)
    }
    
    df['lat'] = df['Location'].apply(lambda x: locations_coords.get(x.split()[0] if '(' not in x else x.split()[0], (7.8731, 80.7718))[0])
    df['lon'] = df['Location'].apply(lambda x: locations_coords.get(x.split()[0] if '(' not in x else x.split()[0], (7.8731, 80.7718))[1])
    
    fig = px.scatter_mapbox(
        df,
        lat='lat',
        lon='lon',
        color='Risk_Profile_Score',
        size='Total_Accidents',
        hover_name='Location',
        hover_data=['Risk_Category', 'Total_Accidents'],
        color_continuous_scale='RdYlGn_r',
        size_max=30,
        zoom=7,
        title='District Risk Profile Map'
    )
    
    fig.update_layout(mapbox_style='open-street-map')
    fig.update_layout(height=600)
    return fig

def create_risk_profile_chart(df):
    """Create bar chart of risk profiles"""
    fig = px.bar(
        df.sort_values('Risk_Profile_Score', ascending=False),
        x='Location',
        y='Risk_Profile_Score',
        color='Risk_Category',
        title='Risk Profile Score by District',
        labels={'Risk_Profile_Score': 'Risk Score (Higher = More Vulnerable Users)'}
    )
    
    fig.add_hline(y=1, line_dash="dash", line_color="green", annotation_text="Low Risk")
    fig.add_hline(y=3, line_dash="dash", line_color="red", annotation_text="High Risk")
    fig.update_layout(xaxis_tickangle=-45, height=500)
    return fig

def create_vehicle_composition_chart(df, location):
    """Create pie chart for vehicle composition"""
    location_data = df[df['Location'] == location].iloc[0]
    vehicle_types = ['Motor Car', 'Dual Purpose Vehicle', 'Lorry', 'Cycle', 
                     'Motor Cycle/Moped', 'Three wheeler', 'SLT Bus', 
                     'Private Bus', 'Intercity Bus']
    
    values = [location_data.get(vt, 0) for vt in vehicle_types]
    vehicle_types = [vt for vt, v in zip(vehicle_types, values) if v > 0]
    values = [v for v in values if v > 0]
    
    fig = px.pie(values=values, names=vehicle_types, title=f'Vehicle Distribution - {location}', hole=0.4)
    return fig

def create_comparison_chart(df):
    """Compare urban vs rural patterns"""
    urban_data = df[df['Area_Type'] == 'Urban']
    rural_data = df[df['Area_Type'] == 'Rural']
    vehicle_types = ['Motor Cycle/Moped', 'Three wheeler', 'Motor Car', 'Lorry', 'Private Bus']
    
    urban_avg = urban_data[vehicle_types].mean()
    rural_avg = rural_data[vehicle_types].mean()
    
    fig = go.Figure()
    fig.add_trace(go.Bar(name='Urban', x=vehicle_types, y=urban_avg, marker_color='crimson'))
    fig.add_trace(go.Bar(name='Rural', x=vehicle_types, y=rural_avg, marker_color='teal'))
    fig.update_layout(title='Urban vs Rural Accident Patterns', barmode='group', height=500)
    return fig

def create_risk_trend_simulation(years, risk_scores):
    """Create trend simulation chart"""
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=years, y=risk_scores, mode='lines+markers', name='Risk Score'))
    fig.add_hrect(y0=0, y1=1, fillcolor="green", opacity=0.1, annotation_text="Low Risk")
    fig.add_hrect(y0=1, y1=3, fillcolor="yellow", opacity=0.1, annotation_text="Medium Risk")
    fig.add_hrect(y0=3, y1=10, fillcolor="red", opacity=0.1, annotation_text="High Risk")
    fig.update_layout(title='Risk Trend Simulation', height=450)
    return fig

def create_domain_shift_gauge(shift_score):
    """Create gauge chart"""
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=shift_score * 100,
        title={'text': "Distribution Shift (%)"},
        gauge={
            'axis': {'range': [0, 100]},
            'steps': [
                {'range': [0, 20], 'color': "lightgreen"},
                {'range': [20, 50], 'color': "yellow"},
                {'range': [50, 100], 'color': "salmon"}
            ]
        }
    ))
    fig.update_layout(height=400)
    return fig

def create_vehicle_heatmap(df, vehicle_cols):
    """Create correlation heatmap"""
    corr_matrix = df[vehicle_cols[:10]].corr()
    fig = px.imshow(corr_matrix, text_auto=True, color_continuous_scale='RdBu_r', 
                    title='Vehicle Type Correlations', height=600)
    return fig
