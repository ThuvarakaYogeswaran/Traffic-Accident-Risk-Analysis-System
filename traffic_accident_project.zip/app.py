"""
Traffic Accident Risk Analysis Dashboard
Main Streamlit Application
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

# Import custom modules
from data_loader import load_data, preprocess_data, get_vehicle_columns
from feature_engineering import engineer_all_features, categorize_risk
from models import RiskProfileModel, DomainAdaptation, TemporalSimulator
from visualization import *
from utils import *

# Page configuration
st.set_page_config(
    page_title="Traffic Accident Risk Analysis System",
    page_icon="🚦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS - Improved styling
st.markdown("""
    <style>
    .main-header {
        font-size: 2rem;
        color: #1f77b4;
        text-align: center;
        padding: 0.5rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 10px;
        text-align: center;
        margin: 0.5rem;
    }
    .stMetric {
        font-size: 0.9rem;
    }
    /* Fix for Plotly charts */
    .js-plotly-plot .plotly .xtick text, 
    .js-plotly-plot .plotly .ytick text {
        font-size: 11px !important;
    }
    /* Ensure charts don't overflow */
    .stPlotlyChart {
        overflow-x: auto !important;
    }
    </style>
""", unsafe_allow_html=True)

# Initialize session state
if 'model_trained' not in st.session_state:
    st.session_state.model_trained = False
if 'risk_model' not in st.session_state:
    st.session_state.risk_model = None
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False

@st.cache_data
def load_and_process_data():
    """Load and process data with caching"""
    df = load_data()
    df, df_percent, vehicle_cols = preprocess_data(df)
    df = engineer_all_features(df, vehicle_cols)
    return df, df_percent, vehicle_cols

def train_models(df, vehicle_cols):
    """Train ML models"""
    with st.spinner("Training risk prediction models..."):
        model = RiskProfileModel()
        classifier_results = model.train_classifier(df, vehicle_cols)
        regressor_results = model.train_regressor(df, vehicle_cols)
        st.session_state.risk_model = model
        st.session_state.model_trained = True
        return classifier_results, regressor_results

def main():
    # Header
    st.markdown('<div class="main-header">🚦 Traffic Accident Risk Analysis System</div>', unsafe_allow_html=True)
    st.markdown("*Data-driven insights for safer roads in Sri Lanka*")
    st.divider()
    
    # Load data first
    try:
        df, df_percent, vehicle_cols = load_and_process_data()
        st.session_state.data_loaded = True
    except Exception as e:
        st.error(f"Error loading data: {e}")
        st.stop()
    
    # Sidebar
    with st.sidebar:
        st.image("https://img.icons8.com/color/96/000000/traffic-jam.png", width=80)
        st.title("Navigation")
        
        page = st.radio(
            "Select Section",
            ["📊 Dashboard Overview", "📍 Location Analysis", "🤖 ML Predictions", 
             "📈 Policy Simulator", "🔄 Domain Adaptation", "📉 Risk Trends"]
        )
        
        st.divider()
        
        # Year filter (if Year column exists)
        if 'Year' in df.columns:
            st.subheader("📅 Filters")
            years = sorted(df['Year'].unique())
            selected_year = st.selectbox("Select Year", years, index=len(years)-1)
            
            # Filter data based on year selection
            df_filtered = df[df['Year'] == selected_year].copy()
            st.success(f"Showing data for {selected_year}")
        else:
            df_filtered = df.copy()
            selected_year = None
        
        st.divider()
        
        # Quick stats
        st.subheader("📊 Quick Stats")
        st.metric("Total Locations", len(df_filtered['Location'].unique()))
        st.metric("Total Accidents", format_number(df_filtered['Total_Accidents'].sum()))
        
        st.divider()
        
        st.info(
            """
            **System Features:**
            - Real-time risk assessment
            - ML-powered predictions
            - Policy impact simulation
            - Urban-rural adaptation
            """
        )
    
    # Dashboard Overview Page
    if page == "📊 Dashboard Overview":
        st.header("📊 Dashboard Overview")
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        stats = get_statistics_summary(df_filtered)
        
        with col1:
            st.metric("Total Locations", stats['total_locations'])
        with col2:
            st.metric("Total Accidents", format_number(stats['total_accidents']))
        with col3:
            st.metric("High Risk Areas", stats['high_risk_locations'])
        with col4:
            st.metric("Avg Accidents/Location", f"{stats['avg_accidents_per_location']:.0f}")
        
        st.divider()
        
        # Risk Map
        st.subheader("🗺️ Geographic Risk Distribution")
        fig_map = create_risk_map(df_filtered)
        st.plotly_chart(fig_map, use_container_width=True)
        
        # Two columns for impactful charts (REPLACED SECTION)
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("🎯 Top Risk Drivers")
            st.markdown("*Which vehicle types cause the most risk?*")
            
            # Calculate vehicle impact
            impact_df = get_vehicle_impact_analysis(df_filtered, vehicle_cols)
            top_drivers = impact_df.head(5)
            
            fig_drivers = px.bar(
                top_drivers,
                x='Impact_on_Risk',
                y='Vehicle_Type',
                orientation='h',
                title='Most Dangerous Vehicle Types',
                color='Impact_on_Risk',
                color_continuous_scale='Reds',
                text='Impact_on_Risk'
            )
            fig_drivers.update_traces(texttemplate='%{text:.3f}', textposition='outside')
            fig_drivers.update_layout(
                height=400, 
                xaxis_title="Risk Impact Score", 
                yaxis_title="",
                xaxis_range=[0, top_drivers['Impact_on_Risk'].max() * 1.1]
            )
            st.plotly_chart(fig_drivers, use_container_width=True)
            st.caption("💡 **Policy Insight:** Reducing these vehicle types has the highest safety impact")
        
        with col2:
            st.subheader("📊 Risk Distribution")
            st.markdown("*How are districts categorized by risk level?*")
            
            # Risk category distribution
            risk_counts = df_filtered['Risk_Category'].value_counts()
            colors = {
                'Low (Heavy Vehicle Dominated)': '#2ecc71', 
                'Medium (Balanced)': '#f39c12', 
                'High (Vulnerable User Dominated)': '#e74c3c'
            }
            
            fig_pie = px.pie(
                values=risk_counts.values,
                names=risk_counts.index,
                title='District Risk Profile',
                hole=0.4,
                color=risk_counts.index,
                color_discrete_map=colors
            )
            fig_pie.update_traces(textposition='inside', textinfo='percent+label')
            fig_pie.update_layout(height=400, width=400)
            st.plotly_chart(fig_pie, use_container_width=True)
            
            # Quick insight
            high_risk_count = len(df_filtered[df_filtered['Risk_Category'].str.contains('High')])
            medium_risk_count = len(df_filtered[df_filtered['Risk_Category'].str.contains('Medium')])
            low_risk_count = len(df_filtered[df_filtered['Risk_Category'].str.contains('Low')])
            
            col_a, col_b, col_c = st.columns(3)
            with col_a:
                st.metric("🔴 High Risk", high_risk_count)
            with col_b:
                st.metric("🟡 Medium Risk", medium_risk_count)
            with col_c:
                st.metric("🟢 Low Risk", low_risk_count)
        
        # Vehicle correlation heatmap
        st.subheader("🔗 Vehicle Type Correlation Matrix")
        fig_heatmap = create_vehicle_heatmap(df_filtered, vehicle_cols)
        st.plotly_chart(fig_heatmap, use_container_width=True)
        
        # Top risk locations
        col1, col2 = st.columns(2)
        with col1:
            st.subheader("⚠️ Highest Risk Locations")
            high_risk = get_top_risk_locations(df_filtered)
            st.dataframe(high_risk, use_container_width=True)
        
        with col2:
            st.subheader("✅ Lowest Risk Locations")
            low_risk = get_top_safe_locations(df_filtered)
            st.dataframe(low_risk, use_container_width=True)
        
        # Yearly trend if multiple years available
        if 'Year' in df.columns and len(df['Year'].unique()) > 1:
            st.subheader("📈 Yearly Risk Trend")
            yearly_avg = df.groupby('Year')['Risk_Profile_Score'].mean().reset_index()
            fig_yearly = px.line(yearly_avg, x='Year', y='Risk_Profile_Score', 
                                  title='Average Risk Score by Year', markers=True)
            fig_yearly.update_layout(height=400)
            st.plotly_chart(fig_yearly, use_container_width=True)
    
    # Location Analysis Page
    elif page == "📍 Location Analysis":
        st.header("📍 Detailed Location Analysis")
        
        # Location selector
        location = st.selectbox("Select District", sorted(df_filtered['Location'].unique()))
        
        if location:
            location_data = df_filtered[df_filtered['Location'] == location].iloc[0]
            
            # Metrics row
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Accidents", format_number(int(location_data['Total_Accidents'])))
            with col2:
                st.metric("Risk Profile Score", f"{location_data['Risk_Profile_Score']:.2f}")
            with col3:
                risk_cat = location_data['Risk_Category'].split('(')[0] if '(' in location_data['Risk_Category'] else location_data['Risk_Category']
                st.metric("Risk Category", risk_cat)
            with col4:
                st.metric("Area Type", location_data['Area_Type'])
            
            # Yearly trend for this location
            if 'Year' in df.columns:
                st.subheader("📅 Yearly Accident Trend")
                location_yearly = df[df['Location'] == location].groupby('Year')['Total_Accidents'].sum().reset_index()
                fig_yearly_loc = px.bar(location_yearly, x='Year', y='Total_Accidents', 
                                        title=f'Accident Trend for {location}')
                st.plotly_chart(fig_yearly_loc, use_container_width=True)
            
            # Vehicle composition
            st.subheader("Vehicle Accident Distribution")
            fig_pie = create_vehicle_composition_chart(df_filtered, location)
            st.plotly_chart(fig_pie, use_container_width=True)
            
            # Detailed vehicle breakdown
            st.subheader("Detailed Vehicle Accident Counts")
            vehicle_counts = pd.DataFrame({
                'Vehicle Type': vehicle_cols,
                'Accident Count': [location_data[col] for col in vehicle_cols]
            }).sort_values('Accident Count', ascending=False)
            
            st.dataframe(vehicle_counts, use_container_width=True)
    
    # ML Predictions Page
    elif page == "🤖 ML Predictions":
        st.header("🤖 Machine Learning Risk Predictions")
        
        if not st.session_state.model_trained:
            if st.button("🚀 Train Prediction Models"):
                classifier_res, regressor_res = train_models(df_filtered, vehicle_cols)
                st.success("Models trained successfully!")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Classifier Accuracy", f"{classifier_res['cv_mean']:.2%}")
                with col2:
                    st.metric("Regressor R² Score", f"{regressor_res['r2_mean']:.3f}")
                with col3:
                    if 'mae' in regressor_res:
                        st.metric("Mean Absolute Error", f"{regressor_res['mae']:.2f}")
        else:
            st.success("✅ Models are ready!")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Model Status", "Trained")
            with col2:
                st.metric("Risk Categories", len(st.session_state.risk_model.risk_categories))
            with col3:
                st.metric("Features Used", len(vehicle_cols))
            
            # Feature importance
            st.subheader("Vehicle Type Impact on Risk Score")
            importance_df = get_vehicle_impact_analysis(df_filtered, vehicle_cols)
            
            fig_importance = px.bar(
                importance_df.head(10),
                x='Impact_on_Risk',
                y='Vehicle_Type',
                orientation='h',
                title='Top 10 Vehicle Types Impacting Risk Score',
                color='Impact_on_Risk',
                color_continuous_scale='Viridis'
            )
            st.plotly_chart(fig_importance, use_container_width=True)
            
            # Manual prediction
            st.subheader("🔮 Custom Risk Prediction")
            st.markdown("Adjust vehicle counts to see predicted risk category")
            
            col1, col2 = st.columns(2)
            
            with col1:
                test_location = st.selectbox("Select base location", sorted(df_filtered['Location'].unique()))
                base_data = df_filtered[df_filtered['Location'] == test_location].iloc[0]
                
                # Create editable inputs for key vehicle types
                adjustments = {}
                key_types = ['Motor Cycle/Moped', 'Three wheeler', 'Motor Car', 'Private Bus', 'Lorry']
                
                for vt in key_types:
                    if vt in vehicle_cols:
                        adjustments[vt] = st.number_input(
                            f"{vt}",
                            value=int(base_data[vt]),
                            min_value=0,
                            step=10
                        )
            
            with col2:
                if st.button("Predict Risk", type="primary"):
                    # Create feature vector
                    X_test = pd.DataFrame([{col: adjustments.get(col, 0) for col in vehicle_cols}])
                    X_log = np.log1p(X_test)
                    
                    # Predict
                    risk_score = st.session_state.risk_model.predict_risk_score(X_log)[0]
                    risk_category = categorize_risk(risk_score)
                    
                    st.markdown("### 📊 Prediction Results")
                    
                    result_col1, result_col2 = st.columns(2)
                    with result_col1:
                        st.metric("Predicted Risk Score", f"{risk_score:.2f}")
                    with result_col2:
                        st.metric("Risk Category", risk_category)
                    
                    # Gauge chart
                    fig_gauge = go.Figure(go.Indicator(
                        mode="gauge+number",
                        value=risk_score,
                        title={'text': "Risk Score"},
                        gauge={
                            'axis': {'range': [0, 10]},
                            'bar': {'color': "crimson" if risk_score > 3 else "orange" if risk_score > 1 else "green"},
                            'steps': [
                                {'range': [0, 1], 'color': "lightgreen"},
                                {'range': [1, 3], 'color': "yellow"},
                                {'range': [3, 10], 'color': "salmon"}
                            ]
                        }
                    ))
                    fig_gauge.update_layout(height=300)
                    st.plotly_chart(fig_gauge, use_container_width=True)
                    
                    # Recommendation
                    if risk_score > 3:
                        st.warning("⚠️ High Risk Area! Consider policy interventions.")
                    elif risk_score > 1:
                        st.info("📊 Medium Risk Area - Monitor regularly.")
                    else:
                        st.success("✅ Low Risk Area - Good safety measures.")
    
    # Policy Simulator Page
    elif page == "📈 Policy Simulator":
        st.header("📈 Policy Impact Simulator")
        st.markdown("*Simulate how changes in vehicle fleet affect accident risk*")
        
        col1, col2 = st.columns([1, 1.5])
        
        with col1:
            location = st.selectbox("Select District", sorted(df_filtered['Location'].unique()), key="policy_loc")
            vehicle_type = st.selectbox("Select Vehicle Type to Modify", vehicle_cols)
            change_percent = st.slider("Change in Vehicle Count (%)", -50, 100, 0)
            
            if st.button("Simulate Impact", type="primary"):
                result = simulate_policy_change(df_filtered, location, vehicle_type, change_percent, vehicle_cols)
                
                st.markdown("### Simulation Results")
                st.metric("Original Risk Score", f"{result['original_risk']:.2f}")
                st.metric("New Risk Score", f"{result['new_risk']:.2f}")
                st.metric("Absolute Change", f"{result['change']:+.2f}")
                st.metric("Percent Change", f"{result['change_percent']:+.1f}%")
                
                if result['change_percent'] > 0:
                    st.warning(f"⚠️ Risk would increase by {result['change_percent']:.1f}%")
                elif result['change_percent'] < 0:
                    st.success(f"✅ Risk would decrease by {abs(result['change_percent']):.1f}%")
                else:
                    st.info("No change in risk score")
        
        with col2:
            st.subheader("Policy Recommendations")
            
            # Vehicle impact analysis
            impact_df = get_vehicle_impact_analysis(df_filtered, vehicle_cols)
            
            st.markdown("**Top Risk Drivers (reducing these helps most):**")
            for _, row in impact_df.head(5).iterrows():
                st.markdown(f"- 🔴 {row['Vehicle_Type']}: {row['Impact_on_Risk']:.3f} impact")
            
            st.markdown("**Bottom Risk Drivers (safer to increase):**")
            for _, row in impact_df.tail(5).iterrows():
                st.markdown(f"- 🟢 {row['Vehicle_Type']}: {row['Impact_on_Risk']:.3f} impact")
            
            st.info("💡 **Tip:** Policies targeting high-impact vehicle types yield the best results for risk reduction.")
    
    # Domain Adaptation Page
    elif page == "🔄 Domain Adaptation":
        st.header("🔄 Urban-Rural Domain Adaptation")
        st.markdown("*Understanding how accident patterns transfer between urban and rural areas*")
        
        da = DomainAdaptation()
        
        # Check if we have both urban and rural data
        if len(df_filtered[df_filtered['Area_Type'] == 'Urban']) > 0 and len(df_filtered[df_filtered['Area_Type'] == 'Rural']) > 0:
            X_urban, X_rural, urban_df, rural_df = da.prepare_urban_rural_split(df_filtered, vehicle_cols)
            
            # Distribution shift
            st.subheader("Distribution Shift Analysis")
            shift_scores = da.calculate_distribution_shift(
                pd.DataFrame(X_urban), pd.DataFrame(X_rural), vehicle_cols
            )
            
            avg_shift = np.mean(list(shift_scores.values()))
            fig_shift = create_domain_shift_gauge(avg_shift)
            st.plotly_chart(fig_shift, use_container_width=True)
            
            st.info(f"Average Jensen-Shannon divergence: {avg_shift:.3f}")
            st.markdown("*Higher values indicate greater difference between urban and rural accident patterns*")
            
            # Top shifting vehicle types
            shift_df = pd.DataFrame({
                'Vehicle_Type': list(shift_scores.keys()),
                'Shift_Magnitude': list(shift_scores.values())
            }).sort_values('Shift_Magnitude', ascending=False)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Vehicle Types with Highest Shift")
                st.dataframe(shift_df.head(10), use_container_width=True)
                
                fig_shift_bar = px.bar(
                    shift_df.head(10),
                    x='Shift_Magnitude',
                    y='Vehicle_Type',
                    orientation='h',
                    title='Distribution Shift by Vehicle Type'
                )
                st.plotly_chart(fig_shift_bar, use_container_width=True)
            
            with col2:
                st.subheader("Urban vs Rural Comparison")
                
                # Compare average vehicle counts
                comparison = pd.DataFrame({
                    'Urban_Avg': urban_df[vehicle_cols].mean(),
                    'Rural_Avg': rural_df[vehicle_cols].mean(),
                    'Difference': urban_df[vehicle_cols].mean() - rural_df[vehicle_cols].mean()
                }).round(2)
                
                st.dataframe(comparison.head(10), use_container_width=True)
        else:
            st.warning("Insufficient urban/rural data for domain adaptation analysis")
        
        # CORAL alignment explanation
        st.subheader("CORAL Domain Adaptation")
        st.markdown("""
        **CORrelation ALignment (CORAL)** is used to reduce domain shift by aligning the 
        feature distributions of source (urban) and target (rural) domains.
        
        **Applications:**
        - Train on urban data, adapt to rural predictions
        - Identify region-specific traffic patterns
        - Improve model generalization across districts
        """)
    
    # Risk Trends Page
    elif page == "📉 Risk Trends":
        st.header("📉 Future Risk Trend Simulation")
        st.markdown("*Simulated projections based on current patterns*")
        
        # Select location for trend analysis
        location = st.selectbox("Select District for Trend Analysis", sorted(df_filtered['Location'].unique()))
        
        location_data = df_filtered[df_filtered['Location'] == location].copy()
        
        if len(location_data) > 0:
            # Generate synthetic future trends
            years = list(range(2024, 2030))
            
            # Simulate risk trend based on current risk and random factors
            current_risk = location_data['Risk_Profile_Score'].iloc[0]
            risk_trend = [current_risk]
            
            np.random.seed(42)  # For reproducible results
            for year in range(1, 6):
                trend_factor = np.random.normal(0, 0.1)
                if current_risk > 3:
                    change = -0.05 + trend_factor * 0.1
                elif current_risk < 1:
                    change = 0.03 + trend_factor * 0.15
                else:
                    change = 0.02 + trend_factor * 0.12
                
                new_risk = risk_trend[-1] * (1 + change)
                risk_trend.append(max(0.1, new_risk))
            
            # Create trend chart
            fig_trend = create_risk_trend_simulation(years, risk_trend)
            st.plotly_chart(fig_trend, use_container_width=True)
            
            # Projected values table
            trend_df = pd.DataFrame({
                'Year': years,
                'Projected_Risk_Score': [round(x, 2) for x in risk_trend],
                'Change_vs_Previous': ['-'] + [f"{((risk_trend[i] - risk_trend[i-1]) / risk_trend[i-1] * 100):+.1f}%" 
                                               for i in range(1, len(risk_trend))]
            })
            
            st.subheader("Projected Values")
            st.dataframe(trend_df, use_container_width=True)
            
            # Recommendation based on trend
            final_risk = risk_trend[-1]
            if final_risk > current_risk * 1.1:
                st.warning("⚠️ Risk is projected to increase. Consider intervention strategies.")
            elif final_risk < current_risk * 0.9:
                st.success("✅ Risk is projected to decrease. Current policies appear effective.")
            else:
                st.info("📊 Risk is projected to remain stable.")
            
            # Historical trend if multiple years available
            if 'Year' in df.columns and len(df[df['Location'] == location]['Year'].unique()) > 1:
                st.subheader("📊 Historical Trend")
                historical = df[df['Location'] == location].groupby('Year')['Risk_Profile_Score'].mean().reset_index()
                fig_hist = px.line(historical, x='Year', y='Risk_Profile_Score', 
                                   title=f'Historical Risk Trend for {location}', markers=True)
                st.plotly_chart(fig_hist, use_container_width=True)
        else:
            st.error(f"No data available for {location}")
        
        # Disclaimer
        st.caption("""
        *Note: These are simulated projections for demonstration purposes. 
        Real predictions would require historical time-series data.*
        """)
    
    # Footer
    st.divider()
    st.markdown(
        """
        <div style="text-align: center; color: gray;">
        🚦 Traffic Accident Risk Analysis System | Built with Streamlit | Data-driven road safety
        </div>
        """,
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()